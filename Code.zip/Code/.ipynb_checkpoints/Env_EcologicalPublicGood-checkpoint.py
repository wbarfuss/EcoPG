"""
My Eco PG game
"""

import numpy as np

class EcologicalPublicGood(object):
    """classic PD"""

    def __init__(self,
                 NrOfAgents=2,
                 MultiplicationFactor=1.2,
                 SocialCooperationCost=5,
                 EnvSuffering=1,
                 Ccollapseprob=0,
                 Crecoveryprob=0,
                 Dcollapseprob=0,
                 Drecoveryprob=0):
        self.N = NrOfAgents
        self.M = 2
        self.Z = 2

        self.r = MultiplicationFactor
        self.c = SocialCooperationCost
        self.s = -1 * EnvSuffering

        self.Pcc = Ccollapseprob
        self.Pcr = Crecoveryprob
        self.Pdc = Dcollapseprob
        self.Pdr = Drecoveryprob


    def actionticks(self): 
        return [0, 1], ["coop.", "defect."]

    def stateticks(self):
        return [0, 1], ["deg.", "prosp."]

    def TransitionTensor(self):
        """Get the Transition Tensor."""
        dim = np.concatenate(([self.Z],
                              [self.M for _ in range(self.N)],
                              [self.Z]))
        Tsas = np.ones(dim) * (-1)

        for index, _ in np.ndenumerate(Tsas):
            Tsas[index] = self._transition_probability(index[0],
                                                       index[1:-1],
                                                       index[-1])
        return Tsas

    def _transition_probability(self, s, jA, sprim):
        Nc = self.N - sum(jA)
        Nd = sum(jA)

        if s == 1 and sprim == 1:
            # remaining at the props. state
            p = Nc * (1 - self.Pcc) +\
                Nd * (1 - self.Pdc)
        if s == 1 and sprim == 0:
            # collapse
            p = Nd * self.Pdc +\
                Nc * self.Pcc
        if s == 0 and sprim == 1:
            # recovery
            p = Nc * self.Pcr +\
                Nd * self.Pdr
        if s == 0 and sprim == 0:
            # remaining at the prosperous state
            p = Nc * (1 - self.Pcr) + \
                Nd * (1 - self.Pdr)

        return p / self.N


    def RewardTensor(self):
        """Get the Reward Tensor R[i,s,a1,...,aN,s']."""
        dim = np.concatenate(([self.N],
                              [self.Z],
                              [self.M for _ in range(self.N)],
                              [self.Z]))
        Risas = np.zeros(dim)

        for index, _ in np.ndenumerate(Risas):
            Risas[index] = self._reward(index[0], index[1], index[2:-1],
                                        index[-1])
        return Risas


    def _reward(self, i, s, jA, sprim):


        if s == 1 and sprim == 1:
            # while remaining at the prosperous state
            # standard public good
            Nc = self.N - sum(jA)
            Nd = sum(jA)

            Rd = self.r * Nc * self.c / self.N
            Rc = Rd - self.c

            reward = Rd if jA[i] else Rc
        else:
            reward = self.s

        return reward